//Filename: CreativeGUI.java 
//Author: Ajanth Suthan 
//Date Created: May 10, 2023 
//Purpose: This programs makes a progress bar which is initially set to 50 percent, a password box, and a file opener.
//Makes the progress bar 100 percent when a password is entered.

//Import Commands
import java.awt.*; 
import java.awt.event.*;  
import javax.swing.*;
import java.io.*;


//CreativeGUI class creates a progress bar which is initially set to 50 percent, a password box, and a file opener. 
////Makes the progress bar 100 percent when a password is entered.
public class SecondScreen extends JFrame 
  
{
   //Declaring components (JLabels, JTextfields, JMenuItem, JMenu, JMenuBar) of the JFrame 
  private JButton back;
  private JButton profile;
  private JButton sort;
  private JButton newBtn;
  private JButton delete;
  private JButton help;
  private JLabel animeOne;
  private JLabel animeTwo;
  private JLabel animeThree;
  private JLabel animeFour;
  private JLabel animeFive;
  private JLabel animeSix;
  private JLabel animeSeven;
  private JLabel animeEight;
  private JLabel animeNine;
  private JLabel animeTen;
  private JLabel animeEle;
  private JLabel animeTwe;
  private JLabel animeThir;
  private JLabel animeFo;
  private JLabel animeFif;


  






 


  
    
   
   //Constructor to setup GUI components and event handlers 
   public SecondScreen()
   {
      //Initializing components of JFrame
      String x = "Naruto"; 
      String y = "One Piece";
      back = new JButton("Back"); 
      profile = new JButton("Profile");
      sort = new JButton("Sort");
      newBtn = new JButton("New");
      delete = new JButton("Delete");
      help = new JButton("Help");
      animeOne = new JLabel(x);
      animeTwo = new JLabel(y);


      
      
      
      //Sets coordinates of buttons and dimensions (x coordinate, y coordinate, width, height)
      back.setBounds(20, 300, 70, 50); 
      profile.setBounds(140,300,90,50);
      sort.setBounds(260,300,70,50);
      newBtn.setBounds(380,300,70,50);
      delete.setBounds(500,300,70,50);
      help.setBounds(620,300,70,50);
      animeOne.setBounds(360,0,100,30);
      animeTwo.setBounds(360,30,100,30);

          
               
                 
      //adding components to JFrame container  
      add (back);
      add (profile);
      add (sort);    
      add(newBtn);
      add(delete);        
      add(help);
      add(animeOne);
      add(animeTwo);

    
     

      //setting JFrame's title, window size and making it visible 
      setTitle("Password"); //"super" JFrame sets its title
      setSize(720,405); //"super" JFrame sets its initial window size 
      setLayout(null);  //sets layout to null meaning you determine where things are placed  
      setVisible(true); //"super" JFrame shows 
  }
    
  //The main() method 
  public static void main(String[] args)
  {
     SecondScreen app = new SecondScreen();
  }  
}
  
      
      

      
       
  
   
   
   
   

   










      
      

      
       
  
   
   
   
   

   









